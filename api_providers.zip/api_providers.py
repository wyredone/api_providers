# api_provider_manager.py
import json
import os
import sys
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import threading
from pathlib import Path
from typing import Dict, Any, Optional, List
import subprocess

# Auto-install dependencies
try:
    import requests
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests", "-q"])
    import requests


CONFIG_DIR = Path.home() / ".api_provider_manager"
CONFIG_FILE = CONFIG_DIR / "providers.json"
ENCRYPTION_AVAILABLE = False

try:
    import ctypes
    import base64
    ENCRYPTION_AVAILABLE = sys.platform == "win32"
except ImportError:
    pass


class SettingsManager:
    """Reusable settings manager for API providers."""

    PROVIDERS = {
        "OpenRouter": {
            "base_url": "https://openrouter.ai/api/v1",
            "api_key_field": "api_key",
            "supports_models": True,
        },
        "OpenAI": {
            "base_url": "https://api.openai.com/v1",
            "api_key_field": "api_key",
            "supports_models": True,
        },
        "Anthropic": {
            "base_url": "https://api.anthropic.com",
            "api_key_field": "api_key",
            "supports_models": True,
        },
        "Google Gemini": {
            "base_url": "https://generativelanguage.googleapis.com/v1beta/openai/",
            "api_key_field": "api_key",
            "supports_models": True,
        },
        "Ollama": {
            "base_url": "http://localhost:11434/api",
            "api_key_field": None,
            "supports_models": True,
        },
        "Strata": {
            "base_url": "http://localhost:8000",
            "api_key_field": "api_key",
            "supports_models": True,
        },
        "Custom": {
            "base_url": "",
            "api_key_field": "api_key",
            "supports_models": True,
        },
    }

    def __init__(self):
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        self.config = self._load_config()

    def _load_config(self) -> Dict[str, Any]:
        """Load config from file or return defaults."""
        if not CONFIG_FILE.exists():
            return {
                "providers": {},
                "default_provider": None,
                "encrypted": ENCRYPTION_AVAILABLE,
            }
        try:
            with open(CONFIG_FILE, "r") as f:
                return json.load(f)
        except Exception:
            return {
                "providers": {},
                "default_provider": None,
                "encrypted": ENCRYPTION_AVAILABLE,
            }

    def _save_config(self) -> None:
        """Save config to file."""
        try:
            with open(CONFIG_FILE, "w") as f:
                json.dump(self.config, f, indent=2)
            os.chmod(CONFIG_FILE, 0o600)
        except Exception as e:
            raise Exception(f"Failed to save config: {e}")

    def _encrypt_key(self, key: str) -> str:
        """Encrypt API key using Windows DPAPI if available."""
        if not ENCRYPTION_AVAILABLE or not key:
            return key

        try:
            data = key.encode("utf-8")
            blob = ctypes.create_string_buffer(data)
            data_in = ctypes.wintypes.LPBYTE(blob)
            data_out = ctypes.wintypes.LPBYTE()

            res = ctypes.windll.crypt32.CryptProtectData(
                ctypes.byref(data_in),
                ctypes.c_wchar_p("api_key"),
                None,
                None,
                None,
                0x01,
                ctypes.byref(data_out),
            )

            if res:
                encrypted = bytes(data_out.contents)
                return base64.b64encode(encrypted).decode("utf-8")
        except Exception:
            pass
        return key

    def _decrypt_key(self, encrypted_key: str) -> str:
        """Decrypt API key using Windows DPAPI if available."""
        if not ENCRYPTION_AVAILABLE or not encrypted_key:
            return encrypted_key

        try:
            encrypted = base64.b64decode(encrypted_key.encode("utf-8"))
            blob = ctypes.create_string_buffer(encrypted)
            data_in = ctypes.wintypes.LPBYTE(blob)
            data_out = ctypes.wintypes.LPBYTE()

            res = ctypes.windll.crypt32.CryptUnprotectData(
                ctypes.byref(data_in),
                None,
                None,
                None,
                None,
                0x01,
                ctypes.byref(data_out),
            )

            if res:
                decrypted = bytes(data_out.contents)
                return decrypted.decode("utf-8")
        except Exception:
            pass
        return encrypted_key

    def save_provider(self, name: str, settings: Dict[str, str]) -> None:
        """Save provider settings."""
        if "api_key" in settings and settings["api_key"]:
            settings["api_key"] = self._encrypt_key(settings["api_key"])

        self.config["providers"][name] = settings
        self._save_config()

    def load_provider(self, name: str) -> Optional[Dict[str, str]]:
        """Load provider settings."""
        if name not in self.config["providers"]:
            return None

        settings = self.config["providers"][name].copy()
        if "api_key" in settings and settings["api_key"]:
            settings["api_key"] = self._decrypt_key(settings["api_key"])

        return settings

    def delete_provider(self, name: str) -> None:
        """Delete provider settings."""
        if name in self.config["providers"]:
            del self.config["providers"][name]
        if self.config.get("default_provider") == name:
            self.config["default_provider"] = None
        self._save_config()

    def list_providers(self) -> Dict[str, Dict[str, str]]:
        """List all saved providers."""
        result = {}
        for name, settings in self.config["providers"].items():
            result[name] = self.load_provider(name)
        return result

    def set_default_provider(self, name: str) -> None:
        """Set default provider."""
        if name in self.config["providers"]:
            self.config["default_provider"] = name
            self._save_config()

    def get_default_provider(self) -> Optional[str]:
        """Get default provider."""
        return self.config.get("default_provider")

    def export_settings(self, filepath: str) -> None:
        """Export settings (keys encrypted in export)."""
        export_data = {
            "providers": {},
            "default_provider": self.config.get("default_provider"),
        }
        for name, settings in self.config["providers"].items():
            export_data["providers"][name] = settings.copy()

        with open(filepath, "w") as f:
            json.dump(export_data, f, indent=2)
        os.chmod(filepath, 0o600)

    def import_settings(self, filepath: str, merge: bool = True) -> None:
        """Import settings from file."""
        with open(filepath, "r") as f:
            import_data = json.load(f)

        if not merge:
            self.config["providers"] = {}

        self.config["providers"].update(import_data.get("providers", {}))
        self._save_config()


class APIProviderManagerGUI:
    """Main GUI application."""

    def __init__(self, root):
        self.root = root
        self.root.title("API Provider Manager")
        self.root.geometry("1000x750")

        # Color theme - clean and readable
        self.bg_color = "#f5f5f5"
        self.fg_color = "#1a1a1a"
        self.accent_color = "#0066cc"
        self.border_color = "#d0d0d0"
        self.input_bg = "#ffffff"
        self.hover_color = "#0052a3"

        self.root.configure(bg=self.bg_color)

        self.settings = SettingsManager()
        self.available_models: List[Dict[str, str]] = []
        self.setup_styles()
        self.setup_ui()
        self.refresh_provider_list()

    def setup_styles(self):
        """Setup light theme."""
        style = ttk.Style()
        style.theme_use("clam")

        style.configure(
            "TFrame",
            background=self.bg_color,
        )
        style.configure(
            "TLabel",
            background=self.bg_color,
            foreground=self.fg_color,
        )
        style.configure(
            "TButton",
            background=self.accent_color,
            foreground="#ffffff",
            borderwidth=0,
            focuscolor="none",
        )
        style.map(
            "TButton",
            background=[("active", self.hover_color)],
        )
        style.configure(
            "TCombobox",
            fieldbackground=self.input_bg,
            background=self.input_bg,
            foreground=self.fg_color,
        )
        style.configure(
            "TEntry",
            fieldbackground=self.input_bg,
            background=self.input_bg,
            foreground=self.fg_color,
        )
        style.configure(
            "TLabelframe",
            background=self.bg_color,
            foreground=self.fg_color,
        )
        style.configure(
            "TLabelframe.Label",
            background=self.bg_color,
            foreground=self.fg_color,
        )

    def setup_ui(self):
        """Setup UI components."""
        # Header frame
        header = ttk.Frame(self.root)
        header.pack(fill="x", padx=15, pady=15)

        ttk.Label(header, text="Provider:", font=("Segoe UI", 10, "bold")).pack(side="left", padx=5)
        self.provider_var = tk.StringVar()
        self.provider_dropdown = ttk.Combobox(
            header,
            textvariable=self.provider_var,
            values=list(self.settings.PROVIDERS.keys()),
            state="readonly",
            width=25,
            font=("Segoe UI", 10),
        )
        self.provider_dropdown.pack(side="left", padx=5)
        self.provider_dropdown.bind("<<ComboboxSelected>>", self.on_provider_selected)

        # Main content frame
        content = ttk.Frame(self.root)
        content.pack(fill="both", expand=True, padx=15, pady=10)

        # Settings frame
        settings_frame = ttk.LabelFrame(content, text="Provider Settings", padding=15)
        settings_frame.pack(fill="x", pady=10)

        ttk.Label(settings_frame, text="Base URL:", font=("Segoe UI", 10)).grid(row=0, column=0, sticky="w", padx=5, pady=8)
        self.base_url_var = tk.StringVar()
        ttk.Entry(settings_frame, textvariable=self.base_url_var, width=55, font=("Segoe UI", 10)).grid(
            row=0, column=1, columnspan=2, padx=5, pady=8, sticky="ew"
        )

        ttk.Label(settings_frame, text="API Key:", font=("Segoe UI", 10)).grid(row=1, column=0, sticky="w", padx=5, pady=8)
        api_key_frame = ttk.Frame(settings_frame)
        api_key_frame.grid(row=1, column=1, columnspan=2, padx=5, pady=8, sticky="ew")

        self.api_key_var = tk.StringVar()
        self.api_key_entry = ttk.Entry(api_key_frame, textvariable=self.api_key_var, show="•", width=48, font=("Segoe UI", 10))
        self.api_key_entry.pack(side="left", fill="x", expand=True)

        self.show_key_var = tk.BooleanVar()
        ttk.Checkbutton(
            api_key_frame,
            text="Show",
            variable=self.show_key_var,
            command=self.toggle_api_key_visibility,
        ).pack(side="left", padx=8)

        # Models section
        ttk.Label(settings_frame, text="Default Model:", font=("Segoe UI", 10)).grid(
            row=2, column=0, sticky="w", padx=5, pady=8
        )

        model_frame = ttk.Frame(settings_frame)
        model_frame.grid(row=2, column=1, columnspan=2, padx=5, pady=8, sticky="ew")

        self.default_model_var = tk.StringVar()
        self.model_dropdown = ttk.Combobox(
            model_frame,
            textvariable=self.default_model_var,
            state="readonly",
            width=50,
            font=("Segoe UI", 10),
        )
        self.model_dropdown.pack(side="left", fill="x", expand=True, padx=(0, 5))

        ttk.Button(model_frame, text="Fetch", command=self.fetch_models, width=8).pack(side="left", padx=2)

        # Model search frame
        search_frame = ttk.LabelFrame(content, text="Search Models", padding=10)
        search_frame.pack(fill="x", pady=10)

        ttk.Label(search_frame, text="Filter:", font=("Segoe UI", 9)).pack(side="left", padx=5)
        self.search_var = tk.StringVar()
        self.search_var.trace("w", self.filter_models)
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var, width=60, font=("Segoe UI", 10))
        search_entry.pack(side="left", padx=5, fill="x", expand=True)

        ttk.Button(search_frame, text="Clear", command=lambda: self.search_var.set(""), width=8).pack(side="left", padx=2)

        # Models list
        models_frame = ttk.LabelFrame(content, text="Available Models (click to select)", padding=10)
        models_frame.pack(fill="both", expand=True, pady=10)

        scrollbar = ttk.Scrollbar(models_frame)
        scrollbar.pack(side="right", fill="y")

        self.models_text = tk.Text(
            models_frame,
            height=10,
            width=100,
            bg=self.input_bg,
            fg=self.fg_color,
            yscrollcommand=scrollbar.set,
            font=("Consolas", 9),
            cursor="hand2",
        )
        self.models_text.pack(fill="both", expand=True, padx=5, pady=5)
        self.models_text.bind("<Button-1>", self.on_model_click)
        scrollbar.config(command=self.models_text.yview)

        # Buttons frame
        button_frame = ttk.Frame(content)
        button_frame.pack(fill="x", pady=12)

        ttk.Button(button_frame, text="Save", command=self.save_provider, width=12).pack(side="left", padx=3)
        ttk.Button(button_frame, text="Test Connection", command=self.test_connection, width=16).pack(side="left", padx=3)
        ttk.Button(button_frame, text="Delete", command=self.delete_provider, width=12).pack(side="left", padx=3)
        ttk.Button(button_frame, text="Set as Default", command=self.set_default_provider, width=14).pack(side="left", padx=3)

        import_export_frame = ttk.Frame(content)
        import_export_frame.pack(fill="x", pady=8)

        ttk.Button(import_export_frame, text="Import Settings", command=self.import_settings, width=16).pack(
            side="left", padx=3
        )
        ttk.Button(import_export_frame, text="Export Settings", command=self.export_settings, width=16).pack(
            side="left", padx=3
        )

        # Status log
        log_frame = ttk.LabelFrame(content, text="Status", padding=10)
        log_frame.pack(fill="x", pady=10)

        self.status_var = tk.StringVar(value="Ready")
        status_label = ttk.Label(log_frame, textvariable=self.status_var, font=("Segoe UI", 9), foreground="#2d7a3a")
        status_label.pack(padx=5, pady=5, anchor="w")

        # Saved providers frame
        saved_frame = ttk.Frame(content)
        saved_frame.pack(fill="x", pady=10)

        self.saved_providers_var = tk.StringVar()
        ttk.Label(saved_frame, textvariable=self.saved_providers_var, font=("Segoe UI", 9), foreground="#555555").pack(
            padx=5, pady=5, anchor="w"
        )

        settings_frame.columnconfigure(1, weight=1)

    def log(self, message: str):
        """Log message to status."""
        self.status_var.set(message)
        self.root.update()

    def toggle_api_key_visibility(self):
        """Toggle API key visibility."""
        if self.show_key_var.get():
            self.api_key_entry.config(show="")
        else:
            self.api_key_entry.config(show="•")

    def on_provider_selected(self, event=None):
        """Load provider settings when selected."""
        provider_name = self.provider_var.get()
        if not provider_name:
            return

        saved = self.settings.load_provider(provider_name)
        if saved:
            self.base_url_var.set(saved.get("base_url", ""))
            self.api_key_var.set(saved.get("api_key", ""))
            self.default_model_var.set(saved.get("default_model", ""))
            self.log(f"Loaded settings for {provider_name}")
        else:
            default_settings = self.settings.PROVIDERS.get(provider_name, {})
            self.base_url_var.set(default_settings.get("base_url", ""))
            self.api_key_var.set("")
            self.default_model_var.set("")
            self.log(f"No saved settings for {provider_name}; using defaults")

        self.available_models = []
        self.model_dropdown.config(values=[])
        self.models_text.delete("1.0", "end")

    def save_provider(self):
        """Save provider settings."""
        provider_name = self.provider_var.get()
        if not provider_name:
            messagebox.showerror("Error", "Please select a provider")
            return

        settings = {
            "base_url": self.base_url_var.get(),
            "api_key": self.api_key_var.get(),
            "default_model": self.default_model_var.get(),
        }

        try:
            self.settings.save_provider(provider_name, settings)
            self.log(f"✓ Saved {provider_name}")
            self.refresh_provider_list()
        except Exception as e:
            self.log(f"✗ Error: {e}")
            messagebox.showerror("Error", f"Failed to save: {e}")

    def delete_provider(self):
        """Delete provider settings."""
        provider_name = self.provider_var.get()
        if not provider_name:
            messagebox.showerror("Error", "Please select a provider")
            return

        if messagebox.askyesno("Confirm", f"Delete {provider_name} settings?"):
            try:
                self.settings.delete_provider(provider_name)
                self.log(f"✓ Deleted {provider_name}")
                self.base_url_var.set("")
                self.api_key_var.set("")
                self.default_model_var.set("")
                self.refresh_provider_list()
            except Exception as e:
                self.log(f"✗ Error: {e}")
                messagebox.showerror("Error", f"Failed to delete: {e}")

    def set_default_provider(self):
        """Set provider as default."""
        provider_name = self.provider_var.get()
        if not provider_name:
            messagebox.showerror("Error", "Please select a provider")
            return

        try:
            self.settings.set_default_provider(provider_name)
            self.log(f"✓ Set {provider_name} as default")
            self.refresh_provider_list()
        except Exception as e:
            self.log(f"✗ Error: {e}")

    def on_model_click(self, event):
        """Handle model list click to select model."""
        try:
            index = self.models_text.index(f"@{event.x},{event.y}")
            line_start = self.models_text.index(f"{index} linestart")
            line_end = self.models_text.index(f"{index} lineend")
            line_text = self.models_text.get(line_start, line_end).strip()

            if not line_text or line_text.startswith(" "):
                return

            # Extract model ID from line (before " - " or end of line)
            model_id = line_text.split(" - ")[0].strip()

            # Find matching model in available_models
            for model in self.available_models:
                if model["id"] == model_id:
                    self.default_model_var.set(model_id)
                    self.log(f"Selected model: {model_id}")
                    return
        except Exception:
            pass

    def test_connection(self):
        """Test provider connection in background thread."""
        provider_name = self.provider_var.get()
        base_url = self.base_url_var.get()
        api_key = self.api_key_var.get().strip()

        if not provider_name or not base_url:
            messagebox.showerror("Error", "Select provider and set base URL")
            return

        if not api_key:
            messagebox.showerror("Error", "Enter API key to test connection")
            return

        def test():
            try:
                self.log("Testing connection...")
                headers = {"Authorization": f"Bearer {api_key}"}

                url = f"{base_url.rstrip('/')}/models"
                response = requests.get(url, headers=headers, timeout=5)

                if response.status_code == 200:
                    self.log(f"✓ Connection successful ({response.status_code})")
                else:
                    self.log(f"✗ Connection failed ({response.status_code})")
            except Exception as e:
                self.log(f"✗ Connection error: {str(e)[:80]}")

        thread = threading.Thread(target=test, daemon=True)
        thread.start()

    def fetch_models(self):
        """Fetch available models from provider."""
        provider_name = self.provider_var.get()
        base_url = self.base_url_var.get()
        api_key = self.api_key_var.get().strip()

        if not provider_name or not base_url:
            messagebox.showerror("Error", "Select provider and set base URL")
            return

        if not api_key:
            messagebox.showerror("Error", "Enter API key to fetch models")
            return

        def fetch():
            try:
                self.log("Fetching models...")
                self.models_text.delete("1.0", "end")

                headers = {"Authorization": f"Bearer {api_key}"}

                url = f"{base_url.rstrip('/')}/models"
                response = requests.get(url, headers=headers, timeout=15)

                if response.status_code == 200:
                    data = response.json()
                    models = data.get("data", [])

                    self.available_models = []
                    for model in models:
                        # Handle different API response formats
                        if isinstance(model, dict):
                            model_id = model.get("id") or model.get("model")
                            model_name = model.get("name", model.get("display_name", ""))
                        else:
                            model_id = model
                            model_name = ""

                        if model_id:
                            self.available_models.append(
                                {
                                    "id": model_id,
                                    "name": model_name,
                                    "description": model.get("description", "") if isinstance(model, dict) else "",
                                }
                            )

                    self.update_models_display()
                    self.log(f"✓ Fetched {len(self.available_models)} models")
                else:
                    error_text = response.text[:150] if response.text else f"HTTP {response.status_code}"
                    self.log(f"✗ Failed ({response.status_code}): {error_text[:80]}")
                    self.models_text.insert("end", f"Error: {error_text}")
            except Exception as e:
                self.log(f"✗ Error fetching models: {str(e)[:80]}")
                self.models_text.insert("end", f"Error: {str(e)}")

        thread = threading.Thread(target=fetch, daemon=True)
        thread.start()

    def update_models_display(self):
        """Update models display and dropdown."""
        self.models_text.delete("1.0", "end")

        for model in self.available_models:
            display = f"{model['id']}"
            if model["name"]:
                display += f" - {model['name']}"
            if model["description"]:
                display += f"\n  {model['description'][:60]}..."
            self.models_text.insert("end", display + "\n\n")

        model_ids = [m["id"] for m in self.available_models]
        self.model_dropdown.config(values=model_ids)

    def filter_models(self, *args):
        """Filter models based on search."""
        search_term = self.search_var.get().lower()

        self.models_text.delete("1.0", "end")

        filtered = [
            m
            for m in self.available_models
            if search_term in m["id"].lower() or search_term in m["name"].lower()
        ]

        for model in filtered:
            display = f"{model['id']}"
            if model["name"]:
                display += f" - {model['name']}"
            if model["description"]:
                display += f"\n  {model['description'][:60]}..."
            self.models_text.insert("end", display + "\n\n")

        if search_term:
            self.log(f"Showing {len(filtered)} of {len(self.available_models)} models")

    def import_settings(self):
        """Import settings from file."""
        filepath = filedialog.askopenfilename(
            title="Import Settings",
            filetypes=[("JSON", "*.json"), ("All", "*.*")],
        )
        if not filepath:
            return

        try:
            merge = messagebox.askyesno("Merge?", "Merge with existing settings?")
            self.settings.import_settings(filepath, merge=merge)
            self.log(f"✓ Imported settings from {Path(filepath).name}")
            self.refresh_provider_list()
        except Exception as e:
            self.log(f"✗ Import error: {e}")
            messagebox.showerror("Error", f"Failed to import: {e}")

    def export_settings(self):
        """Export settings to file."""
        filepath = filedialog.asksaveasfilename(
            title="Export Settings",
            defaultextension=".json",
            filetypes=[("JSON", "*.json")],
        )
        if not filepath:
            return

        try:
            self.settings.export_settings(filepath)
            self.log(f"✓ Exported settings to {Path(filepath).name}")
        except Exception as e:
            self.log(f"✗ Export error: {e}")
            messagebox.showerror("Error", f"Failed to export: {e}")

    def refresh_provider_list(self):
        """Refresh saved providers display."""
        saved = self.settings.list_providers()
        default = self.settings.get_default_provider()

        provider_text = "Saved: "
        if saved:
            names = [f"{'★ ' if name == default else ''}{name}" for name in saved.keys()]
            provider_text += " | ".join(names)
        else:
            provider_text += "(none)"

        self.saved_providers_var.set(provider_text)


def main():
    root = tk.Tk()
    app = APIProviderManagerGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()